package com.shop.service;

import com.shop.model.Product;

public interface AdminService {
	/* 상품 등록 */
	public void insertpro(Product product);

}
